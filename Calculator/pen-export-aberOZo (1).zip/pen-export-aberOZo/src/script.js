// script.js
function validateForm() {
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    
    if (username == "" || password == "") {
        alert("Both fields must be filled out.");
        return false;
    }

    // Example: You can add additional validations such as password length, special characters, etc.
    if (password.length < 6) {
        alert("Password must be at least 6 characters long.");
        return false;
    }

    // Form is valid
    return true;
}